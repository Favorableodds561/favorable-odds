@echo off
setlocal
title Odd$ Guard
cd /d "%~dp0"

rem Already running as administrator? Go straight to the scan.
net session >nul 2>&1
if %errorlevel%==0 goto run

echo Asking Windows for administrator permission so every check can run...
rem The path goes through an environment variable, not into the command text, so folder names with an apostrophe (O'Brien) still work.
set "GUARD_LAUNCHER=%~f0"
powershell -NoProfile -Command "try { Start-Process -FilePath $env:GUARD_LAUNCHER -Verb RunAs -ErrorAction Stop; exit 0 } catch { exit 1 }"
if %errorlevel%==0 exit /b
echo Permission was not granted. Running a limited scan instead.
echo.

:run
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0OddsGuard.ps1"
echo.
pause
