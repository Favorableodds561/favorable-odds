# Odd$ Guard v0.1

"Who can get into my PC?" A read-only access audit for Windows by Favorable Odds Tech Solutions.

## Run it
1. Copy this folder to the PC or a USB stick.
2. Double-click `Run-OddsGuard.bat` and choose **Yes** when Windows asks for permission.
3. The report opens in the browser. Copies are saved in `Reports\` (HTML for people, JSON for tools).

If the folder came from a zip download, right-click the zip > Properties > **Unblock** before extracting.

## What it checks
- **Remote-control apps:** 30 known tools (AnyDesk, TeamViewer, ScreenConnect, UltraViewer and more), including unattended-access services and copies running from Downloads.
- **Windows remote access:** Remote Desktop, Remote Assistance, and open remote-access ports.
- **Accounts:** extra administrators, accounts hidden from the sign-in screen, Guest and built-in Administrator.
- **Persistence:** startup items and non-Microsoft scheduled tasks, flagging hidden or encoded scripts and unsigned programs in temp or download folders.
- **Security settings:** antivirus status, antivirus exclusions, firewall, and User Account Control.
- **Browsers and network:** force-installed and screen-sharing extensions, hosts-file redirects, and proxies.

## What it never does
It changes nothing, sends nothing over the internet, and stores results only in `Reports\`.

## Options
```
.\OddsGuard.ps1 -DemoReport      # sample report for sales demos, no scan
.\OddsGuard.ps1 -OutputDir D:\   # choose where reports go
.\OddsGuard.ps1 -NoOpen          # do not open the report when done
```

## Before selling it
- Sign `OddsGuard.ps1` with a code-signing certificate so antivirus and SmartScreen trust it.
- Test on Windows 10 and 11, Home and Pro, with and without admin rights.
